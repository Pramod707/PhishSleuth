# PhishSleuth-API
This is server side code for our project PhishSleuth. It contains flask server code and some web scraping code.
